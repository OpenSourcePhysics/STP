(function(){var P$=java.io,I$=[];
/*i*/var C$=Clazz.newInterface(P$, "FileFilter");
})();
;Clazz.setTVer('3.2.8-v1');//Created 2020-02-05 08:09:18 Java2ScriptVisitor version 3.2.8-v1 net.sf.j2s.core.jar version 3.2.8-v1
