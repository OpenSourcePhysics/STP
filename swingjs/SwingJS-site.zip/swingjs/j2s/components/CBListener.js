(function(){var P$=Clazz.newPackage("components"),p$1={},I$=[[0,'javax.swing.JFrame','javax.swing.JCheckBox','java.awt.FlowLayout','javax.swing.JButton','javax.swing.JMenuBar','javax.swing.JMenu','javax.swing.JMenuItem','test.components.GlassPaneDemo','test.components.MyGlassPane','javax.swing.SwingUtilities','java.awt.Color','test.components.CBListener','java.awt.Toolkit','java.awt.event.MouseEvent']],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CBListener", null, 'javax.swing.event.MouseInputAdapter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['toolkit','java.awt.Toolkit','liveButton','java.awt.Component','menuBar','javax.swing.JMenuBar','glassPane','test.components.MyGlassPane','contentPane','java.awt.Container']]]

Clazz.newMeth(C$, 'c$$java_awt_Component$javax_swing_JMenuBar$test_components_MyGlassPane$java_awt_Container', function (liveButton, menuBar, glassPane, contentPane) {
Clazz.super_(C$, this);
this.toolkit=$I$(13).getDefaultToolkit$();
this.liveButton=liveButton;
this.menuBar=menuBar;
this.glassPane=glassPane;
this.contentPane=contentPane;
}, 1);

Clazz.newMeth(C$, 'mouseMoved$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, false]);
});

Clazz.newMeth(C$, 'mouseDragged$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, false]);
});

Clazz.newMeth(C$, 'mouseClicked$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, false]);
});

Clazz.newMeth(C$, 'mouseEntered$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, false]);
});

Clazz.newMeth(C$, 'mouseExited$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, false]);
});

Clazz.newMeth(C$, 'mousePressed$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, false]);
});

Clazz.newMeth(C$, 'mouseReleased$java_awt_event_MouseEvent', function (e) {
p$1.redispatchMouseEvent$java_awt_event_MouseEvent$Z.apply(this, [e, true]);
});

Clazz.newMeth(C$, 'redispatchMouseEvent$java_awt_event_MouseEvent$Z', function (e, repaint) {
var glassPanePoint=e.getPoint$();
var container=this.contentPane;
var containerPoint=$I$(10).convertPoint$java_awt_Component$java_awt_Point$java_awt_Component(this.glassPane, glassPanePoint, this.contentPane);
if (containerPoint.y < 0) {
if (containerPoint.y + this.menuBar.getHeight$() >= 0) {
} else {
}} else {
var component=$I$(10).getDeepestComponentAt$java_awt_Component$I$I(container, containerPoint.x, containerPoint.y);
if ((component != null ) && (component.equals$O(this.liveButton)) ) {
var componentPoint=$I$(10).convertPoint$java_awt_Component$java_awt_Point$java_awt_Component(this.glassPane, glassPanePoint, component);
component.dispatchEvent$java_awt_AWTEvent(Clazz.new_([component, e.getID$(), e.getWhen$(), e.getModifiers$(), componentPoint.x, componentPoint.y, e.getClickCount$(), e.isPopupTrigger$()],$I$(14,1).c$$java_awt_Component$I$J$I$I$I$I$Z));
}}if (repaint) {
this.glassPane.setPoint$java_awt_Point(glassPanePoint);
this.glassPane.repaint$();
}}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-16 19:32:09 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
