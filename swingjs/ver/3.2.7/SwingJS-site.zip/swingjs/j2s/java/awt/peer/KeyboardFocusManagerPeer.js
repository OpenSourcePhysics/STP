(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "KeyboardFocusManagerPeer");
})();
;Clazz.setTVer('3.2.7-v5');//Created 2020-02-01 07:02:11 Java2ScriptVisitor version 3.2.7-v5 net.sf.j2s.core.jar version 3.2.7-v5
