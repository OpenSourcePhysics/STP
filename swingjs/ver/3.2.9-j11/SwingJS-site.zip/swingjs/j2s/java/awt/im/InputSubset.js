(function(){var P$=Clazz.newPackage("java.awt.im"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InputSubset", null, ['Character','.Subset']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['LATIN','java.awt.im.InputSubset','+LATIN_DIGITS','+TRADITIONAL_HANZI','+SIMPLIFIED_HANZI','+KANJI','+HANJA','+HALFWIDTH_KATAKANA','+FULLWIDTH_LATIN','+FULLWIDTH_DIGITS']]]

Clazz.newMeth(C$, 'c$$S', function (name) {
;C$.superclazz.c$$S.apply(this,[name]);C$.$init$.apply(this);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.LATIN=Clazz.new_(C$.c$$S,["LATIN"]);
C$.LATIN_DIGITS=Clazz.new_(C$.c$$S,["LATIN_DIGITS"]);
C$.TRADITIONAL_HANZI=Clazz.new_(C$.c$$S,["TRADITIONAL_HANZI"]);
C$.SIMPLIFIED_HANZI=Clazz.new_(C$.c$$S,["SIMPLIFIED_HANZI"]);
C$.KANJI=Clazz.new_(C$.c$$S,["KANJI"]);
C$.HANJA=Clazz.new_(C$.c$$S,["HANJA"]);
C$.HALFWIDTH_KATAKANA=Clazz.new_(C$.c$$S,["HALFWIDTH_KATAKANA"]);
C$.FULLWIDTH_LATIN=Clazz.new_(C$.c$$S,["FULLWIDTH_LATIN"]);
C$.FULLWIDTH_DIGITS=Clazz.new_(C$.c$$S,["FULLWIDTH_DIGITS"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.9-v1');//Created 2020-04-15 16:11:07 Java2ScriptVisitor version 3.2.9-v1 net.sf.j2s.core.jar version 3.2.9-v1
